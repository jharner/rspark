#' @param seed A random seed. Set this value if you need your results to be
#'   reproducible across repeated calls.
