#' @param weights.column The name of the column to use as weights for the model fit.
