#' @param iter.max The maximum number of iterations to use.
