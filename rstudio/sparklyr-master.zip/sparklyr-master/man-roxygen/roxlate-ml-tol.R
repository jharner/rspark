#' @param tolerance Param for the convergence tolerance for iterative algorithms.
