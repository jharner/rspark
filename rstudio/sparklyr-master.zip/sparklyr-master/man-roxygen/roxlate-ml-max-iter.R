#' @param max.iter The maximum number of iterations to use.
