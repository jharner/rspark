#' @param x An object coercable to a Spark DataFrame (typically, a
#'   \code{tbl_spark}).

