# using "testthat" for tests
# tests are located in inst/tests/testthat

library(testthat)
test_check("Rhipe")