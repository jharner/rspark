## This file contains tests that perform a simple map-reduce job to
## test Rhipe functions.

context("Simple mr job")

test_that("test rhinit", {
   rhinit()
})

test.dir <- file.path(rhoptions()$HADOOP.TMP.FOLDER, "rhipeTest")

test_that("clean rhoptions()$HADOOP.TMP.FOLDER/rhipeTest and set working directory", {
  if(rhexists(test.dir))
    rhdel(test.dir)

  rhmkdir(test.dir)
  hdfs.setwd(test.dir)
})

test_that("buffer overflow job setup", {
  rhwrite(lapply(1:25, function(x) list(x, x)), file = "rhtest")
})

test_that("buffer overflow job", {

  # map that collects "1" as key and a single-row data-frame
  map <- expression({
    Map(function(k,v){
      rhcollect("1", data.frame(key = k, val = v, stringsAsFactors = FALSE))
    }, map.keys, map.values)
  })

  reduce <- expression(
    pre = {
      adata <- list()
    },
    reduce = {
      adata[[length(adata) + 1]] <- reduce.values
    },
    post = {
      rhcollect(reduce.key, adata)
    }
  )

  b <- rhwatch(map = map, reduce = reduce,
    input = "rhtest", output = "rhtestout",
    mapred = list(mapred.reduce.tasks = 1, rhipe_reduce_buff_size = 10))

  res <- rbind(
    do.call(rbind,b[[1]][[2]][[1]]),
    do.call(rbind,b[[1]][[2]][[2]]),
    do.call(rbind,b[[1]][[2]][[3]])
  )

  expect_true(nrow(res) == 25)
})
